//full name: Tong Wu
//USCID: 9675835428

public class Event {
	String eventName_;
	String eventTime_;
	String month_;
	int year_;
	int date_;
	
	//default constructor
	Event(){}
	
	//custom constructor
	Event(String name, String time, String m, int d, int y){
		String tempmonth = changeMonth(m);
		
		eventName_ = name;
		eventTime_ = time;
		month_ = tempmonth;
		year_ = y;
		date_ = d;
	}
	
	//prints event details
	public String getEvent(){
		String toReturn = eventName_ + ", "+eventTime_ + ", "
				+ month_+" "+ date_ + ", "+ year_;
		
		return toReturn;
	}
	
	public String changeMonth(String s){
		String ss = s.toLowerCase();
		
		if(ss.equals("1") || ss.equals("january") ){
			return "january";
		}else if(ss.equals("2") || ss.equals("february")){
			return "february";
		}else if(ss.equals("3") || ss.equals("march")){
			return "march";
		}else if(ss.equals("4") || ss.equals("april")){
			return "april";
		}else if(ss.equals("5") || ss.equals("may")){
			return "may";
		}else if(ss.equals("6") || ss.equals("june")){
			return "june";
		}else if(ss.equals("7") || ss.equals("july")){
			return "july";
		}else if(ss.equals("8") || ss.equals("august")){
			return "august";
		}else if(ss.equals("9") || ss.equals("september")){
			return "september";
		}else if(ss.equals("10") || ss.equals("october")){
			return "october";	
		}else if(ss.equals("11") || ss.equals("november")){
			return "november";	
		}else if(ss.equals("12") || ss.equals("december")){
			return "december";
		}
		return null;
	}
	
	
}
