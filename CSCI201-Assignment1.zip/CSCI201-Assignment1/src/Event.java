
public class Event {
	String eventName_;
	String eventTime_;
	String month_;
	int year_;
	int date_;
	
	//default constructor
	Event(){}
	
	//custom constructor
	Event(String name, String time, String m, int d, int y){
		eventName_ = name;
		eventTime_ = time;
		month_ = m;
		year_ = y;
		date_ = d;
	}
	
	//prints event details
	public String getEvent(){
		String toReturn = eventName_ + ", "+eventTime_ + ", "
				+ month_+" "+ date_ + ", "+ year_;
		
		return toReturn;
	}
	
	
}
