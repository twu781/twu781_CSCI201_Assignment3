//full name: Tong Wu
//USCID: 9675835428

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Scanner;
import java.util.Vector;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Calender {

	public static Vector<Person> people_ = new Vector<Person>();
	public static Boolean foundFile = false;
	public static Boolean isdone = false;
	public static String filename_ = "";
	public static Boolean changed = false;
	
	
	public void addPerson(Person p){
		people_.addElement(p);
	}
	
	public void listAll(){
		if(people_.size() == 0){
			System.out.println("User list empty. No more users to remove.");	
			return;
		}
		
		System.out.println("");
		for (int i = 0 ; i < people_.size(); i++){
			System.out.println("\t"+ (i+1) + ") " +  people_.get(i).getName());		
			people_.get(i).listEvents();
		}
		
	}
	
	public void listNames(){
		System.out.println("");
		for (int i = 0 ; i < people_.size(); i++){
			System.out.println("\t"+ (i+1) + ") " +  people_.get(i).getName());		
		}
		System.out.println("");
		
	}
	//sort users asscending
	public void sortAsc(){
		if(people_.size() <=1){
			return;
		}
		
		int n = people_.size();
		
        for (int i = 0; i < n-1; i++){
            for (int j = 0; j < n-i-1; j++){
            	
                if (people_.get(j).getName().compareToIgnoreCase(people_.get(j+1).getName()) > 0)
                {
                    // swap temp and arr[i]
                	Collections.swap(people_, j, j+1);
                }
            }
        }
	}
	
	//sort users descending
	public void sortDes(){
		if(people_.size() <=1){
			return;
		}
		
		int n = people_.size();
		
        for (int i = 0; i < n-1; i++){
            for (int j = 0; j < n-i-1; j++){
            	
                if (people_.get(j).getName().compareToIgnoreCase(people_.get(j+1).getName()) < 0)
                {
                    // swap temp and arr[i]
                	Collections.swap(people_, j, j+1);
                }
            }
        }
	}
	
	public void addUser(){
		Scanner readin = new Scanner(System.in);
		Boolean validName = false;
		
		
		while(!validName){
			System.out.print("What is the user's name? ");
			String inputName = readin.nextLine();
			
			//check for valid name input
			String[] words = inputName.split("\\W+");
			
			if( words.length != 2 ){
				System.out.println("Invalid, must have first and last name. \n");
				
			}else{
				Person toAdd = new Person(words[0], words[1]);
				 people_.addElement(toAdd);
				validName = true;
			}
		}

		changed = true;
	}
	
	public void saveFile(){
		
		JSONObject toPrint = new JSONObject();
		JSONArray allUsers = new JSONArray();
		
		for(int i = 0 ; i < people_.size(); i ++){
			
			JSONObject wrap = new JSONObject();
			//store Name object
			JSONObject obj = new JSONObject();
			obj.put("Fname", people_.get(i).Fname_);
			obj.put("Lname", people_.get(i).Lname_);
			
			wrap.put("Name", obj);
			
			
			
			JSONArray events = new JSONArray();
			for(int j = 0; j < people_.get(i).myEvents_.size() ; j ++){
				//store event object
				JSONObject eventTime = new JSONObject();
				JSONObject time = new JSONObject();
				eventTime.put("Title", people_.get(i).myEvents_.get(j).eventName_);
				eventTime.put("Time", people_.get(i).myEvents_.get(j).eventTime_);
				time.put("Month", people_.get(i).myEvents_.get(j).month_);
				time.put("Day", people_.get(i).myEvents_.get(j).date_);
				time.put("Year", people_.get(i).myEvents_.get(j).year_);			
				eventTime.put("Date", time);	
				
				events.add(eventTime);
			}
			
			wrap.put("Events", events);
			
			allUsers.add(wrap);
			
		}
		
		toPrint.put("Users", allUsers);
		//print json file
		try (FileWriter file = new FileWriter(filename_)) {
			file.write(toPrint.toJSONString());
		} catch (FileNotFoundException e) {
        	System.out.println("Output file could not be found.\n");
        } catch (IOException e) {
        	System.out.println("Unable to print to output file.\n");
        } 
	}
	
	public void removeUser(){
		Scanner readin = new Scanner(System.in);
		
		if(people_.size() == 0){
			System.out.println("\nUser list empty. No more users to remove.");
			return;
		}
		listNames();
		
		System.out.print("To which user would you like to remove? ");
		String userInput = readin.nextLine();
		int usertoChange = Integer.parseInt(userInput);
		
		if(usertoChange < 0 || usertoChange > people_.size()){
			System.out.println("Invalid User");
			return;
		}
		
		people_.remove(usertoChange-1);
		changed =true;
	}
	
	public void addEvent(){

		if(people_.size() == 0){
			System.out.println("Calender is Empty.");
			return;
		}
		
		Scanner readin = new Scanner(System.in);
		listNames();	
		
		System.out.print("To which user would you like to add an event? ");
		
		try {
			
			String userInput = readin.nextLine();
			int usertoChange = Integer.parseInt(userInput);
			System.out.print("\n");
			
			if(usertoChange < 0 || usertoChange > people_.size()){
				System.out.println("Invalid User");
				return;
			}
			//get event info
			System.out.print("What is the title of the event? ");
			String title = readin.nextLine();
			System.out.print("\n");
			
			System.out.print("What time is the event? ");
			String time = readin.nextLine();
			System.out.print("\n");
			
			System.out.print("What month? ");
			String month = readin.nextLine();
			int rmonth = Integer.parseInt(month);
			while(rmonth<1 || rmonth > 12){
				System.out.println("Invalid month. Please enter valid month. ");
				System.out.print("What month? ");
				month = readin.nextLine();
				rmonth = Integer.parseInt(month);
			}
			System.out.print("\n");
			
			System.out.print("What day? ");
			String day = readin.nextLine();
			int rday = Integer.parseInt(day);
			while(rday<1 || rday > 31){
				System.out.println("Invalid day. Please enter valid day. ");
				System.out.print("What day? ");
				day = readin.nextLine();
				rday = Integer.parseInt(day);
			}
			System.out.print("\n");
			
			System.out.print("What year? ");
			String year = readin.nextLine();
			int ryear = Integer.parseInt(year);
			System.out.print("\n");
			
			//create new event
			 Event tempEvent = new Event(title, time, month, rday, ryear);
			 
			 System.out.println("Added: "+ tempEvent.getEvent());
			
			 people_.elementAt(usertoChange-1).addEvent(tempEvent);
			 people_.elementAt(usertoChange-1).sortEvents();
			 
			 changed = true;
			
		} catch (NumberFormatException e) {
		    //code
			System.out.println("Invalid input");
						
		}
		
	}
	
	public void removeEvent(){

		if(people_.size() == 0){
			System.out.println("Calender is Empty.");
			return;
		}
		
		Scanner readin = new Scanner(System.in);
		listNames();
		System.out.print("To which user would you like to remove an event? ");
		
		//choose user
		try {
			String userInput = readin.nextLine();
			int usertoChange = Integer.parseInt(userInput);
			System.out.print("\n");
			
			while(usertoChange < 0 || usertoChange > people_.size()){
				System.out.println("Invalid user. Please enter valid user. ");
				System.out.print("To which user would you like to remove an event? ");
				userInput = readin.nextLine();
				usertoChange = Integer.parseInt(userInput);
				
			}
			
			if( people_.get(usertoChange-1).myEvents_.size() == 0){
				System.out.println("No events to delete.");
				return;
			}
			
			people_.get(usertoChange-1).printEvents();
			
			//select user to remove enet from
			System.out.print("\n");
			System.out.print("Which event would you like to remove? ");
			userInput = readin.nextLine();
			int toRemove = Integer.parseInt(userInput);
			
			while(toRemove < 0 || toRemove > people_.get(usertoChange-1).myEvents_.size()){
				System.out.println("Invalid event. Please enter valid event. ");
				System.out.print("Which event would you like to remove? ");
				userInput = readin.nextLine();
				toRemove = Integer.parseInt(userInput);
				
			}
			
			//remove event
			people_.get(usertoChange-1).deleteEvent(toRemove);
			people_.elementAt(usertoChange-1).sortEvents();
			
			changed = true;
			
		} catch (NumberFormatException e) {
		    //code
			System.out.println("Invalid input");
						
		}
		
	}
	
	//processes user input
	public void processInput (int input){
		Scanner readin = new Scanner(System.in);

		if(input == 8){
			isdone = true;
			
			//check for changes made
			if(changed){
				System.out.println("\nChanges have been made since the file was last saved.");
				System.out.println("\t1) Yes");
				System.out.println("\t2) No");
				System.out.print("Would you like to save files before exiting? ");
				
				try {
					String userInput = readin.nextLine();
					int choice = Integer.parseInt(userInput);
					if(choice == 1){
						saveFile();
						System.out.println("\nFile was saved");
					}else{
						System.out.println("\nFile was not saved");
					}
					
				} catch (NumberFormatException e) {
				    //code
					System.out.println("Invalid input");
								
				}
							
			}	
			
			System.out.println("\nThank you for using my program!");
		}
		//invalid input
		if(input < 1 || input > 8){
			System.out.println("\nThat is not a valid input\n");
			return;
		}
		if (input == 1){
			listAll();
		}else if (input == 2){
			addUser();
		}else if (input == 3){
			removeUser();
			
		}else if(input == 4){
			addEvent();
		}else if (input == 5){
			removeEvent();
		}else if (input == 6){
		
			System.out.println("\n\t 1) Ascending (A-Z)");
			System.out.println("\t 2) Descending (Z-A)\n");
			System.out.print("How would you like to sort? ");
			
			try {
				String userInput = readin.nextLine();
				int choice = Integer.parseInt(userInput);
				if(choice ==1){
					sortAsc();
				}else if (choice == 2){
					sortDes();
				}
			} catch (NumberFormatException e) {
			    //code
				System.out.println("Invalid input");
							
			}
					
		}else if (input == 7){
			saveFile();
			System.out.println("File was saved.");
		}
			
	}
	
	public static void main (String[] args){
	
		Calender myCalender = new Calender();
		JSONParser parser = new JSONParser();
		Scanner scan = new Scanner(System.in);
		
		
		while(!foundFile){
			
			System.out.print("What is the name of the input file? ");
			String inputfilename = scan.nextLine();
			
			//read JSON file
			try {
				
	            Object obj = parser.parse(new FileReader(inputfilename)); 
	            JSONObject jsonObject = (JSONObject) obj;
	            
	            foundFile = true;
	            filename_ = inputfilename;
	           
	            // loop users array
	            JSONArray users = (JSONArray) jsonObject.get("Users");
	          
	            for (int i=0; i < users.size(); i++) {
	            	//get user data
	               JSONObject innerObj = (JSONObject) users.get(i);
	               JSONObject userName = (JSONObject) innerObj.get("Name");
	               
	               String Fname = (String) userName.get("Fname");
	               String Lname = (String) userName.get("Lname");
	               
	               //generate new person
	               Person tempPerson = new Person(Fname, Lname);
	      
	               JSONArray events = (JSONArray) innerObj.get("Events");
	               
	               //loop through events array
	               for(int j = 0 ; j < events.size(); j++){
	            	   
	            	   //get events data & convert
	            	   JSONObject eventObj = (JSONObject) events.get(j);
	            	   JSONObject dateObj = (JSONObject) eventObj.get("Date");
	            	   
	            	   String title = (String) eventObj.get("Title");
	            	   String time = (String) eventObj.get("Time");
	            	   String month = (String) dateObj.get("Month");
	            	   long day = (long) dateObj.get("Day");
	            	   long year = (long) dateObj.get("Year"); 
	            	   
	            	   int rday = (int) day;
	            	   int ryear = (int) year;
	            	   
	            	   //add event to person and person to calender
	            	   Event tempEvent = new Event(title, time, month, rday, ryear);
	            	   String eventData = tempEvent.getEvent();
	            	   
	            	   tempPerson.addEvent(tempEvent);
	            	   tempPerson.sortEvents();
	            	   
	               }
	             
	               myCalender.addPerson(tempPerson);
	                
	            }
	            

	        } catch (FileNotFoundException e) {
	        	System.out.println("Input file could not be found.\n");
	        } catch (IOException e) {
	        	System.out.println("Unable to read input file.\n");
	        } catch (ParseException e) {
	        	System.out.println("Incorrect Formatting.\n");
	        }
		}
		
		//Calender Program
		while(!isdone){
			System.out.println("\n\t1) Display User's Calender ");
			System.out.println("\t2) Add User ");
			System.out.println("\t3) Remove User ");
			System.out.println("\t4) Add Event ");
			System.out.println("\t5) Delete Event ");
			System.out.println("\t6) Sort Users ");
			System.out.println("\t7) Write File ");
			System.out.println("\t8) Exit ");
			System.out.print(" \nWhat would you like to do? ");
			
			String userInput = scan.nextLine();
			
			try {
				int val = Integer.parseInt(userInput);
				myCalender.processInput(val);
			} catch (NumberFormatException e) {
			    //code
				System.out.println("Invalid input");
					
			}
			
		
		}
			
		scan.close();
		 
	}
	
	
}
