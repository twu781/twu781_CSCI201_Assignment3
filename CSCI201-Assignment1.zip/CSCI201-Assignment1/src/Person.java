import java.util.Collections;
import java.util.Vector;

public class Person {
	
	String Fname_, Lname_;
	public Vector<Event> myEvents_ = new Vector<Event>();
	

	Person(String fname, String lname){
		Fname_ = fname;
		Lname_ = lname;
	}
	
	
	public void getInfo(){
		System.out.print(Lname_ + ", " + Fname_);
	}
	
	public String getName(){
		return Lname_ + ", " + Fname_;
	}
	
	
	public void addEvent(Event e){
		myEvents_.addElement(e);
	}
	
	public void deleteEvent(int i){
		myEvents_.remove(i-1);
	}
	
	//lists events in 123 order
	public void printEvents(){
		System.out.println("");
		for(int i = 0 ; i < myEvents_.size(); i++){
			
			String tempEvent = myEvents_.get(i).getEvent();
			System.out.println(("\t"+ (i+1) +") " +tempEvent));
			
		}
	}

	//converts string months into respective int
	public int changeMonth(String s){
		String ss = s.toLowerCase();
		
		if(ss.equals("january")){
			return 1;
		}else if(ss.equals("february")){
			return 2;
		}else if(ss.equals("march")){
			return 3;
		}else if(ss.equals("april")){
			return 4;
		}else if(ss.equals("may")){
			return 5;
		}else if(ss.equals("june")){
			return 6;
		}else if(ss.equals("july")){
			return 7;
		}else if(ss.equals("august")){
			return 8;
		}else if(ss.equals("steptember")){
			return 9;
		}else if(ss.equals("october")){
			return 10;	
		}else if(ss.equals("november")){
			return 11;	
		}else if(ss.equals("december")){
			return 12;
		}
		return -1;
	}
	
	//returns true if event a < event b, false otherwise
    public Boolean compareEvents(Event a, Event b){
		
    	int amonth = changeMonth(a.month_);
    	int bmonth = changeMonth(b.month_);
    	
    	
    	if (a.year_ < b.year_){
      		return true;
      	}else if(  b.year_ < a.year_){
          return false;
        }
      	else if(amonth < bmonth){
      		return true;
      	}else if( bmonth < amonth){
          return false;
        }
      	else if(a.date_ < b.date_){
      		return true;
      	}else if(b.date_< a.date_ ){
          return false;
        }else{
        	return false;
        }
      	
    	
	}
	
    //sorts events
	public void sortEvents(){
		if(myEvents_.size() <=1){
			return;
		}
		
		int n = myEvents_.size();
		
        for (int i = 0; i < n-1; i++){
            for (int j = 0; j < n-i-1; j++){
            	
                if ( !compareEvents( myEvents_.get(j), myEvents_.get(j+1) ))
                {
                    // swap temp and arr[i]
                	System.out.print(compareEvents( myEvents_.get(j), myEvents_.get(j+1) ));
                	Collections.swap(myEvents_, j, j+1);
                }
            }
        }
	}
	
	//lists events in abc order
	public void listEvents(){
		for(int i = 0 ; i < myEvents_.size(); i++){
			
			String tempEvent = myEvents_.get(i).getEvent();
			char let = (char) (i + 97);
			
			System.out.println("\t \t"+ let+ ") "+ tempEvent);
		}
	}
	
}
